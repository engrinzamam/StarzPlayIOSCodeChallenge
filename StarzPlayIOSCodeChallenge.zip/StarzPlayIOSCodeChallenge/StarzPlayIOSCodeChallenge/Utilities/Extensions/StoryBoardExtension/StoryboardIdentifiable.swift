//
//  StoryboardIdentifiable.swift
//  StarzPlayIOSCodeChallenge
//
//  Created by Inzamam Ul Haq on 26/01/2025.
//

import UIKit

protocol StoryboardIdentifiable {
    static var storyboardIdentifier: String { get }
}

extension StoryboardIdentifiable where Self: UIViewController {
    static var storyboardIdentifier: String {
        return String(describing: self)
    }
}
