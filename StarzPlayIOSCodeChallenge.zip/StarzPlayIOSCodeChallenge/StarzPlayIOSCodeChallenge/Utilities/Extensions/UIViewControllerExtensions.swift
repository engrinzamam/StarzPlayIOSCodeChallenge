//
//  UIViewControllerExtensions.swift
//  StarzPlayIOSCodeChallenge
//
//  Created by Inzamam Ul Haq on 26/01/2025.
//

import UIKit

protocol ViewControllerExtensionMethodsProtocol {
    func hideProgress()
    func showProgress()
}

extension UIViewController: ViewControllerExtensionMethodsProtocol, StoryboardIdentifiable {
    
    // MARK: Show/Hide Progress Methods
    // To show/hide progress we can integrate MBProgressHUD pod or can implement our own using activity indicator
    func showProgress() {
        
//        let progressHud = MBProgressHUD.showAdded(to: self.view, animated: true)
//
//        progressHud.label.textColor = UIConfiguration.WhiteColor
//        progressHud.bezelView.style = .solidColor
//        progressHud.bezelView.color = UIConfiguration.DarkGreyColor
//        progressHud.label.text = Constants.PleaseWaitMsg
    }
    
    func hideProgress() {
        
//        MBProgressHUD.hide(for: self.view, animated: true)
    }
}
