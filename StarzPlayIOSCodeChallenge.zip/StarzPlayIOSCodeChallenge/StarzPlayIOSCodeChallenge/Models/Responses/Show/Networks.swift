//
//  Networks.swift
//  StarzPlayIOSCodeChallenge
//
//  Created by Inzamam Ul Haq on 26/01/2025.
//

import Foundation

struct Networks: Codable {
    let name: String?
    let id: Int?
    let logoPath: String?
    let originCountry: String?

    enum CodingKeys: String, CodingKey {

        case name = "name"
        case id = "id"
        case logoPath = "logo_path"
        case originCountry = "origin_country"
    }

    init(from decoder: Decoder) throws {
        
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        logoPath = try values.decodeIfPresent(String.self, forKey: .logoPath)
        originCountry = try values.decodeIfPresent(String.self, forKey: .originCountry)
    }

}

