//
//  BuildConfiguration.swift
//  StarzPlayIOSCodeChallenge
//
//  Created by Inzamam Ul Haq on 26/01/2025.
//

import Foundation

enum Environment: String {
    
    case debug = "Debug"
    case staging = "Staging"
    case release = "Release"
}


class BuildConfiguration {
    
    static let shared = BuildConfiguration()
    var environment: Environment = .debug
    
    public var baseURL: String {
        return "https://api.themoviedb.org/3"
    }
    
    public var imageBaseURL: String {
        return "https://image.tmdb.org/t/p/original"
    }
    
    public var tmdbAPIKey: String {
        return "ecef14eac236a5d4ec6ac3a4a4761e8f"
    }
    
    // If there is need to attach port manually with baseURL
    public var port: String {
        
        return ""
    }
}
