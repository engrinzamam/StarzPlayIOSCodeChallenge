//
//  APIConfig.swift
//  StarzPlayIOSCodeChallenge
//
//  Created by Inzamam Ul Haq on 26/01/2025.
//

import Foundation

struct APIConfig {
    
    // MARK: - BaseUrl -
    
    static func getBaseUrl() -> String {
        return "\(BuildConfiguration.shared.baseURL)\(BuildConfiguration.shared.port)"
    }
    
    // MARK: - Enable/disbale API Logs -
    static let debug = BuildConfiguration.shared.environment != .release //Production
    
    // MARK: Endpoints
    static let GetShowInfoEndpoint = "/tv/\(Constants.PlaceholderShowId)"
    static let GetSeasonInfoEndpoint = "/tv/\(Constants.PlaceholderShowId)/season/\(Constants.PlaceholderSeasonNo)"
    static let GetEpisodeInfoEndpoint = "/tv/\(Constants.PlaceholderShowId)/season/\(Constants.PlaceholderSeasonNo)/episode/\(Constants.PlaceholderEpisodeNo)"
    
    // MARK: VideoURL 
    static var video: String = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" /**  video : static  base URL for video's **/
    static var video1 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
}
