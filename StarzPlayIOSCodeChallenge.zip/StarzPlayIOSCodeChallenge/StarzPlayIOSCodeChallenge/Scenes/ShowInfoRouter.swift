//
//  ShowInfoRouter.swift
//  StarzPlayIOSCodeChallenge
//
//  Created by Inzamam Ul Haq on 26/01/2025.
//

import UIKit

@objc protocol ShowInfoRoutingLogic
{
    //func routeToSomewhere(segue: UIStoryboardSegue?)
}

protocol ShowInfoDataPassing
{
    var dataStore: ShowInfoDataStore? { get }
}

class ShowInfoRouter: NSObject, ShowInfoRoutingLogic, ShowInfoDataPassing
{
    weak var viewController: ShowInfoViewController?
    var dataStore: ShowInfoDataStore?
    
    // MARK: Routing
}
